package com.example.prox0;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.prox0.database.DatabaseHelper;
import com.example.prox0.model.Experience;
import android.util.Log;
import java.util.Calendar;

public class AddExperienceActivity extends AppCompatActivity {

    private Spinner spinnerCategoria; // Nuevo spinner
    private EditText etProducto, etServicio, etCosto, etDescripcion;
    private EditText etLocation; // opcional: recoge ubicación si el layout la provee
    private Button btnBack, btnSave, btnSaveFavorite, btnShareWhatsapp;
    private DatabaseHelper databaseHelper;
    private boolean isFavorite = false;

    // Variables para almacenar las fechas ISO que se enviarán al webhook
    private String startDate = ""; // e.g. 2025-10-25T08:00:00-06:00
    private String endDate = "";

    // Categorías disponibles
    private static final String[] categorias = {
         "🍽️ Comidas & Restaurantes",
         "🛍️ Compras & Productos",
         "✈️ Viajes & Lugares",
         "🎬 Entretenimiento"
     };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_experience);

        initViews();
        setupCategorySpinner();
        setupListeners();
    }

    private void initViews() {
        spinnerCategoria = findViewById(R.id.spinner_categoria); // Nuevo spinner
        etProducto = findViewById(R.id.et_producto);
        etServicio = findViewById(R.id.et_servicio);
        etCosto = findViewById(R.id.et_costo);
        etDescripcion = findViewById(R.id.et_descripcion);
        // etLocation es opcional: buscar el id dinámicamente para evitar referencia R.id.et_location si no existe
        int locId = getResources().getIdentifier("et_location", "id", getPackageName());
        if (locId != 0) {
            etLocation = findViewById(locId);
        } else {
            etLocation = null;
        }
        btnBack = findViewById(R.id.btn_back);
        btnSave = findViewById(R.id.btn_save);
        btnSaveFavorite = findViewById(R.id.btn_save_favorite);
        btnShareWhatsapp = findViewById(R.id.btn_share_whatsapp);

        databaseHelper = new DatabaseHelper(this);
    }

    private void setupCategorySpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categorias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapter);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnSave.setOnClickListener(v -> saveExperience());

        btnSaveFavorite.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            btnSaveFavorite.setText(isFavorite ? getString(R.string.favorite_selected) : getString(R.string.favorite_default));
            btnSaveFavorite.setBackgroundResource(isFavorite ? R.drawable.button_primary : R.drawable.button_secondary);
        });

        btnShareWhatsapp.setOnClickListener(v -> shareOnWhatsApp());
    }

    private void saveExperience() {
        String categoria = spinnerCategoria.getSelectedItem().toString(); // Obtener categoría seleccionada
        String producto = etProducto.getText().toString().trim();
        String servicio = etServicio.getText().toString().trim();
        String costoStr = etCosto.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();

        // Validaciones
        if (TextUtils.isEmpty(producto) && TextUtils.isEmpty(servicio)) {
            Toast.makeText(this, getString(R.string.error_product_or_service), Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(costoStr)) {
            Toast.makeText(this, getString(R.string.error_cost_required), Toast.LENGTH_SHORT).show();
            return;
        }

        double costo;
        try {
            costo = Double.parseDouble(costoStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, getString(R.string.error_cost_invalid), Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear y guardar experiencia con categoría
        Experience experience = new Experience(categoria, producto, servicio, costo, descripcion);
        // mantener compatibilidad: el estado favorito depende solo de la UI (isFavorite)
        experience.setFavorite(isFavorite);

        long result = databaseHelper.insertExperience(experience);

        if (result != -1) {
            Toast.makeText(this, getString(R.string.saved_success), Toast.LENGTH_SHORT).show();

            // Construir título para el webhook: preferir producto > servicio > categoría
            String titleForWebhook;
            if (!TextUtils.isEmpty(producto)) {
                titleForWebhook = producto;
            } else if (!TextUtils.isEmpty(servicio)) {
                titleForWebhook = servicio;
            } else {
                titleForWebhook = categoria;
            }

            // Si startDate/endDate fueron establecidas por selectores, úsalas; si no, usa valores por defecto
            String start = !TextUtils.isEmpty(startDate) ? startDate : "2025-10-25T08:00:00-06:00";
            String end = !TextUtils.isEmpty(endDate) ? endDate : "2025-10-25T09:00:00-06:00";

            // Ubicación: enviar exactamente lo que el usuario escribió; si no escribió nada, enviar cadena vacía
            String location;
            if (etLocation != null) {
                location = etLocation.getText().toString().trim(); // puede quedar "" si no escribió
            } else {
                location = ""; // no hay campo en UI -> enviar vacío para que n8n maneje
            }

            // Loggear los valores que enviaremos para depuración
            Log.i("Webhook", "Preparando envío: title='" + titleForWebhook + "' description='" + descripcion + "' location='" + location + "' start='" + start + "' end='" + end + "'");

            // Llamada al método que hace el POST al webhook (usa HttpURLConnection)
            MainActivity.sendExperienceToWebhook(this, titleForWebhook, descripcion, start, end, location);

            // Limpiar los campos solo después de preparar y enviar los datos reales
            clearFields();
         } else {
             Toast.makeText(this, getString(R.string.saved_error), Toast.LENGTH_SHORT).show();
         }
    }

    private void shareOnWhatsApp() {
        String categoria = spinnerCategoria.getSelectedItem().toString();
        String producto = etProducto.getText().toString().trim();
        String servicio = etServicio.getText().toString().trim();
        String costoStr = etCosto.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();

        if (TextUtils.isEmpty(producto) && TextUtils.isEmpty(servicio)) {
            Toast.makeText(this, getString(R.string.error_share_info), Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder message = new StringBuilder();
        message.append("🎉 *Mi nueva experiencia en ProX*\n\n");
        message.append("📂 *Categoría:* ").append(categoria).append("\n"); // Incluir categoría

        if (!TextUtils.isEmpty(producto)) {
            message.append("📦 *Producto:* ").append(producto).append("\n");
        }

        if (!TextUtils.isEmpty(servicio)) {
            message.append("🔧 *Servicio:* ").append(servicio).append("\n");
        }

        if (!TextUtils.isEmpty(costoStr)) {
            message.append("💰 *Costo:* $").append(costoStr).append("\n");
        }

        if (!TextUtils.isEmpty(descripcion)) {
            message.append("📝 *Descripción:* ").append(descripcion).append("\n");
        }

        message.append("\n¡Te recomiendo probarlo! 👍");

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(message.toString())));

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.no_whatsapp), Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        spinnerCategoria.setSelection(0); // Resetear spinner a primera opción
        etProducto.setText("");
        etServicio.setText("");
        etCosto.setText("");
        etDescripcion.setText("");
        isFavorite = false;
        btnSaveFavorite.setText(getString(R.string.favorite_default));
        btnSaveFavorite.setBackgroundResource(R.drawable.button_secondary);
    }

    // Public API para establecer start/end desde componentes (year, month, day, hour, minute)
    // month: 1..12
    public void setStartFromComponents(int year, int month, int day, int hour, int minute, String offset) {
        if (offset == null || offset.isEmpty()) offset = "-06:00";
        this.startDate = MainActivity.buildIsoFromComponents(year, month, day, hour, minute, offset);
        Log.i("Webhook", "startDate establecido: " + this.startDate);
    }

    public void setEndFromComponents(int year, int month, int day, int hour, int minute, String offset) {
        if (offset == null || offset.isEmpty()) offset = "-06:00";
        this.endDate = MainActivity.buildIsoFromComponents(year, month, day, hour, minute, offset);
        Log.i("Webhook", "endDate establecido: " + this.endDate);
    }

    // Public API para establecer start/end usando solo la hora (usa fecha actual)
    @SuppressWarnings("unused")
    public void setStartFromTimeOnly(int hour, int minute, String offset) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        setStartFromComponents(year, month, day, hour, minute, offset);
    }

    @SuppressWarnings("unused")
    public void setEndFromTimeOnly(int hour, int minute, String offset) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        setEndFromComponents(year, month, day, hour, minute, offset);
    }
}
