package com.example.prox0;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.prox0.notifications.NotificationService;

// Nuevos imports para la petición HTTP
import android.content.Context;
import android.os.StrictMode;
import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private Button btnLogout;
    private CardView cardAddExperience, cardHistory, cardChat, cardFavorites, cardShareWhatsapp;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupWelcomeMessage();
        setupListeners();

        // Inicializar notificaciones inteligentes
        initNotifications();
    }

    private void initViews() {
        tvWelcome = findViewById(R.id.tv_welcome);
        btnLogout = findViewById(R.id.btn_logout);
        cardAddExperience = findViewById(R.id.card_add_experience);
        cardHistory = findViewById(R.id.card_history);
        cardChat = findViewById(R.id.card_chat);
        cardFavorites = findViewById(R.id.card_favorites);
        cardShareWhatsapp = findViewById(R.id.card_share_whatsapp);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
    }

    private void setupWelcomeMessage() {
        String currentUser = sharedPreferences.getString("currentUser", "Usuario");
        // Usar recurso de strings para i18n y evitar concatenación en setText
        tvWelcome.setText(getString(R.string.welcome_user, currentUser));
    }

    private void setupListeners() {
        // Reemplazado por lambdas (requiere compatibilidad con Java 8+ en el proyecto)
        btnLogout.setOnClickListener(v -> logout());

        cardAddExperience.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddExperienceActivity.class);
            startActivity(intent);
        });

        cardHistory.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
        });

        cardChat.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ChatActivity.class);
            startActivity(intent);
        });

        cardFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
            startActivity(intent);
        });

        // Nuevo listener para compartir por WhatsApp
        cardShareWhatsapp.setOnClickListener(v -> shareToWhatsApp());
    }

    private void initNotifications() {
        // Programar notificaciones inteligentes
        NotificationService.scheduleNextNotification(this);
    }

    private void logout() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.remove("currentUser");
        editor.apply();

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void shareToWhatsApp() {
        String currentUser = sharedPreferences.getString("currentUser", "Usuario");
        String shareText = "📲 ¡Hola! Te comparto mi app ProX Experience 🌟\n\n" +
                "Una app increíble para registrar todas mis experiencias:\n" +
                "✈️ Viajes\n" +
                "🍽️ Comidas\n" +
                "🛍️ Compras\n" +
                "🎬 Entretenimiento\n\n" +
                "¡Descárgala y registra tus momentos especiales! 😊\n\n" +
                "Enviado por: " + currentUser;

        try {
            Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
            whatsappIntent.setType("text/plain");
            whatsappIntent.setPackage("com.whatsapp");
            whatsappIntent.putExtra(Intent.EXTRA_TEXT, shareText);
            startActivity(whatsappIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            // Si WhatsApp no está instalado, usar compartir genérico
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "ProX Experience App");

            Intent chooser = Intent.createChooser(shareIntent, "Compartir ProX Experience");
            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(chooser);
            } else {
                Toast.makeText(this, "No se encontró ninguna app para compartir", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Helper: convertir un valor de tiempo (HH:mm or HH:mm:ss, opcionalmente con offset) o ya-datetime en ISO completo usando Calendar/SimpleDateFormat
    private static String ensureIsoDateTime(String value) {
        if (value == null) return "";
        value = value.trim();
        if (value.isEmpty()) return "";
        // Si ya contiene 'T' asumimos que es un datetime completo (o ISO) y lo devolvemos tal cual
        if (value.contains("T")) return value;

        // Si el valor es solo hora (HH:mm o HH:mm:ss o con offset), separar time y offset
        String timePart = value;
        String offsetPart = "";
        if (value.matches(".*-\\d{2}:\\d{2}$")) {
            int idx = value.lastIndexOf('-');
            String possibleOffset = value.substring(idx);
            if (possibleOffset.matches("-\\d{2}:\\d{2}")) {
                timePart = value.substring(0, idx);
                offsetPart = possibleOffset;
            }
        }

        if (timePart.matches("\\d{2}:\\d{2}$")) {
            timePart = timePart + ":00";
        }

        if (offsetPart.isEmpty()) offsetPart = "-06:00";

        // Construir fecha actual con Calendar
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        String dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month, day);

        // Formatear con SimpleDateFormat y TimeZone
        try {
            String tzId = "GMT" + offsetPart; // ej. GMT-06:00
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone(tzId));
            // Parsear date+time en Calendar y formatear
            Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone(tzId));
            c2.set(Calendar.YEAR, year);
            c2.set(Calendar.MONTH, month - 1);
            c2.set(Calendar.DAY_OF_MONTH, day);
            String[] parts = timePart.split(":");
            int hh = Integer.parseInt(parts[0]);
            int mm = Integer.parseInt(parts[1]);
            int ss = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            c2.set(Calendar.HOUR_OF_DAY, hh);
            c2.set(Calendar.MINUTE, mm);
            c2.set(Calendar.SECOND, ss);
            return sdf.format(c2.getTime());
        } catch (Exception e) {
            Log.e("Webhook", "Error formateando fecha ISO: " + e.getMessage(), e);
            // Fallback simple
            return dateStr + "T" + timePart + offsetPart;
        }
    }

    // Construye un ISO 8601 completo (yyyy-MM-dd'T'HH:mm:ssXXX) desde componentes de fecha/hora y un offset (ej. "-06:00").
    // Este método es público y estático porque otras actividades lo invocan (p.ej. AddExperienceActivity).
    public static String buildIsoFromComponents(int year, int month, int day, int hour, int minute, String offset) {
        if (offset == null || offset.isEmpty()) offset = "-06:00";
        try {
            String tzId = "GMT" + offset; // Ej: GMT-06:00
            TimeZone tz = TimeZone.getTimeZone(tzId);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
            sdf.setTimeZone(tz);

            Calendar c = Calendar.getInstance(tz);
            c.set(Calendar.YEAR, year);
            c.set(Calendar.MONTH, month - 1);
            c.set(Calendar.DAY_OF_MONTH, day);
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, minute);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);

            return sdf.format(c.getTime());
        } catch (Exception e) {
            Log.e("Webhook", "Error construyendo ISO desde componentes: " + e.getMessage(), e);
            // Fallback simple: construir manualmente sin zona formateada
            String monthStr = String.format(Locale.US, "%02d", month);
            String dayStr = String.format(Locale.US, "%02d", day);
            String hourStr = String.format(Locale.US, "%02d", hour);
            String minuteStr = String.format(Locale.US, "%02d", minute);
            return String.format(Locale.US, "%04d-%s-%sT%s:%s:00%s", year, monthStr, dayStr, hourStr, minuteStr, offset);
        }
    }

    // Nuevo método: envía la experiencia al webhook usando HttpURLConnection
    // Inserte este método dentro de la clase MainActivity (después de shareToWhatsApp)
    public static void sendExperienceToWebhook(Context context, String title, String description, String start, String end, String location) {
         // Permitir operaciones de red en hilo principal (solo para pruebas)
         StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
         StrictMode.setThreadPolicy(policy);

         try {
            // Validaciones: ningún campo requerido debe estar vacío
            // Logear valores entrantes para depuración
            Log.i("Webhook", "Valores entrantes: title='" + String.valueOf(title) + "' description='" + String.valueOf(description) + "' location='" + String.valueOf(location) + "'");

            // Enviar exactamente lo que llegó desde la app: no rellenar con textos genéricos.
            // Si algún campo es null, convertirlo a cadena vacía para que n8n maneje el vacío.
            if (title == null) {
                title = "";
            } else {
                title = title.trim();
            }

            if (description == null) {
                description = "";
            } else {
                description = description.trim();
            }

            if (location == null) {
                location = "";
            } else {
                location = location.trim();
            }

            // Si los valores contienen textos por defecto o placeholders usados en la UI,
            // tratarlos como vacíos para que n8n pueda aplicar sus propios defaults.
            // Ejemplos: categorías del spinner que se usaban como título por defecto, o textos genéricos.
            if (!title.isEmpty()) {
                // Texto por defecto introducido en AddExperienceActivity cuando no hay producto/servicio
                String[] uiCategoryPlaceholders = new String[] {
                        "🍽️ Comidas & Restaurantes",
                        "🛍️ Compras & Productos",
                        "✈️ Viajes & Lugares",
                        "🎬 Entretenimiento"
                };
                for (String ph : uiCategoryPlaceholders) {
                    if (title.equals(ph)) {
                        title = "";
                        break;
                    }
                }

                // Otros placeholders comunes que no deben enviarse como contenido real
                if (title.equalsIgnoreCase("sin título") || title.startsWith("`") || title.equalsIgnoreCase("n/a") || title.equals("-")) {
                    title = "";
                }
            }

            if (!description.isEmpty()) {
                if (description.equalsIgnoreCase("sin descripción") || description.equalsIgnoreCase("n/a") || description.startsWith("`")) {
                    description = "";
                }
            }

            if (!location.isEmpty()) {
                if (location.equalsIgnoreCase("sin ubicación") || location.equalsIgnoreCase("n/a") || location.startsWith("`")) {
                    location = "";
                }
            }

            Log.i("Webhook", "Final payload values: title='" + title + "' description='" + description + "' location='" + location + "'");

            // Convertir start/end si vienen solo como hora a ISO completo
            String startIso = ensureIsoDateTime(start);
            String endIso = ensureIsoDateTime(end);

            // Validar que startIso / endIso estén en formato ISO 8601 esperado
            if (!isValidIso8601(startIso)) {
                Log.e("Webhook", "startDate inválido o mal formateado: " + startIso);
                if (context != null) Toast.makeText(context, "startDate inválido", Toast.LENGTH_LONG).show();
                return;
            }
            if (!isValidIso8601(endIso)) {
                Log.e("Webhook", "endDate inválido o mal formateado: " + endIso);
                if (context != null) Toast.makeText(context, "endDate inválido", Toast.LENGTH_LONG).show();
                return;
            }

             JSONObject json = new JSONObject();
             json.put("title", title);
             json.put("description", description);
             json.put("location", location);
             // Usar las claves exactas solicitadas por el usuario
             json.put("startDate", startIso);
             json.put("endDate", endIso);

             String payload = json.toString();

             // Usar exclusivamente la URL de producción indicada (sin fallback)
             String webhookUrl = "https://primary-production-2563.up.railway.app/webhook/task-created";
             webhookUrl = webhookUrl.trim();

             Log.i("Webhook", "Enviando POST a: '" + webhookUrl + "' Payload=" + payload);

             URL url = new URL(webhookUrl);
             HttpURLConnection conn = (HttpURLConnection) url.openConnection();
             conn.setRequestMethod("POST");
             conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
             conn.setConnectTimeout(15000);
             conn.setReadTimeout(15000);
             conn.setDoOutput(true);

             OutputStream os = conn.getOutputStream();
             os.write(payload.getBytes(StandardCharsets.UTF_8));
             os.flush();
             os.close();

             int responseCode = conn.getResponseCode();
             if (responseCode >= 200 && responseCode < 300) {
                 Log.i("Webhook", "Enviado con éxito: " + payload + " ResponseCode=" + responseCode + " URL=" + webhookUrl);
                 if (context != null) Toast.makeText(context, context.getString(R.string.event_sent_success), Toast.LENGTH_SHORT).show();
             } else {
                String responseMessage = conn.getResponseMessage();
                String responseBody = "";
                try {
                    java.io.InputStream err = conn.getErrorStream();
                    if (err == null) err = conn.getInputStream();
                    if (err != null) {
                        java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(err, StandardCharsets.UTF_8));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line).append('\n');
                        }
                        reader.close();
                        responseBody = sb.toString();
                    }
                } catch (Exception readEx) {
                    Log.e("Webhook", "No se pudo leer el cuerpo de la respuesta: " + readEx.getMessage(), readEx);
                }
                Log.e("Webhook", "Error al enviar. Code=" + responseCode + " Message=" + responseMessage + " Payload=" + payload + " ResponseBody=" + responseBody + " URL=" + webhookUrl);
                if (context != null) Toast.makeText(context, context.getString(R.string.error_sending_webhook, responseMessage), Toast.LENGTH_LONG).show();
             }

             conn.disconnect();

        } catch (Exception e) {
            Log.e("Webhook", "Excepción al enviar webhook: " + e.getMessage(), e);
            if (context != null) Toast.makeText(context, context.getString(R.string.exception_sending_webhook, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    // Validar ISO 8601 (yyyy-MM-dd'T'HH:mm:ssXXX) usando SimpleDateFormat parse
    private static boolean isValidIso8601(String iso) {
        if (iso == null || iso.trim().isEmpty()) return false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
            sdf.setLenient(false);
            sdf.parse(iso);
            return true;
        } catch (Exception e) {
            Log.e("Webhook", "Fecha ISO inválida: " + iso + " - " + e.getMessage());
            return false;
        }
    }
}
